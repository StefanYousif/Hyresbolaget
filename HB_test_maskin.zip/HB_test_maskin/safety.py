googlekey = "AIzaSyBmbZ5XUpd_lAF-VKhnO846OyqSZ9b0bII"

DB_HOST = "pgserver.mau.se"
DB_NAME = "am5391"
DB_USER = "am5391"
DB_PASS = "g7hwpp5h"